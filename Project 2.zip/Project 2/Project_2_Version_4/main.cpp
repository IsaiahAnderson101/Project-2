/* 
 * File:   main.cpp
 * Author: Isaiah Anderson
 * Created on June 3th, 2024, 12:03 pm
 * Purpose: Black Jack Game
 */

//System Libraries
#include <iostream>  //Input Output Library
#include <iomanip> //Manipulate cout statements
#include <cstdlib> //Utilize random generator 
#include <ctime> //Utilize time in c++
#include <cmath>
#include <vector> //Library to utilize vectors
#include <fstream> //Include fstream for file I/O
#include <string>
using namespace std;

//User Libraries

//Global Constants not Variables
const int SIZE = 52; //Deck size is always 52 (global constant)
const float PI = 3.14159f;  // Constant for math

//Science, Math, Conversions, Dimensions

//Function Prototypes
void hit(int [], char [], int &);
void fillAr(int [], const int); //52 random card numbers (parallel  array)
void fillSu(char [], const int); //4 suits divided into 13 cards (parallel array)
void prinAr(int [], const int, int);
void start(int [], char [], int&, string name = "Player"); //Start of game, player is given two cards
bool decide(int [], char [], int&, int&, int); //The player is given his options and once he's done, the function turns false to signal the dealers turn
void deal(int [], char[], int&);
void winner(int, int, int, int&, vector<int>&); // Updated prototype
bool playA();
int bet(int&);
void shuffle(int [], const int);
string nameC(int, char[], int);
string suitC(char [], int);
void saveGameState(const int balance, const int wins, const int losses);
void loadGameState(int &balance, int &wins, int &losses);
void saveHighestWins(const vector<int>& highestWins);
void loadHighestWins(vector<int>& highestWins);
void bubbleSort(vector<int>& vec);


//Execution begins here at main
int main(int argc, char** argv) {
    
    //Set random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    string user1;
    string dealer;
    int player;
    int dealr;
    int array[SIZE];
    char suit[SIZE];
    vector<int> highestWins;
    bool again;
    bool conti;
    int betP; //Bet position for current game
    int balance;
    int wins;
    int losses;
    
    //Initialize Variables
    conti = true;
    balance = 1000;
    wins = 0;
    losses = 0;

    // Load game state from file
    loadGameState(balance, wins, losses);
    loadHighestWins(highestWins);

    do{
        // Get the player's bet
        betP = bet(balance);
        user1 = "Player"; //Adds an extra parameter for hit function to personalize based on the player/dealer 
        dealer = "Dealer";
        again = true;
        
        // Fill the deck arrays with values
        fillAr(array, SIZE);
        fillSu(suit, SIZE);
        
        // Initial cards dealt to player and dealer
        start(array, suit, player, user1);
        start(array, suit, dealr, dealer);
        
        // Player's turn
        while(again == true) {
            again = decide(array, suit, player, betP, balance); //if the player stands or gets over 21, again will return false
        }
        
        // Dealer's turn if player hasn't busted
        if(player<=21) {
            deal(array, suit, dealr);
        }
        
        // Determine winner and update balance
        winner(player, dealr, betP, balance, highestWins);
        
        // Ask if the player wants to play again
        conti = playA();
        if(conti==true) {
            shuffle(array, SIZE);
        }
    }
    while(conti==true);
    
    // Save game state to file before exiting
    saveGameState(balance, wins, losses);
    
    // Save highest wins to file before exiting
    saveHighestWins(highestWins);
    
    // Print highest wins at the end
    bubbleSort(highestWins);
    cout << "Highest Wins: ";
    int index = 0;
    while (index < highestWins.size()) {
        cout << highestWins[index] << " ";
        index++;
    }
    cout << endl;
    
    //Exit the Program
    return 0;
}

void shuffle(int array[], const int SIZE) { //Shuffling feature when the game is over
    for (int i = 0; i < SIZE; i++) {
        int ranNum = rand() % SIZE;
        int holder = array[i];
        array[i] = array[ranNum];
        array[ranNum] = holder;
    }
}

int bet(int& balance) {
    int bet; 
    cout << "Your balance is: " << balance << endl;
    cout << "Enter the amount you want to be bet: " << endl;
    cin>> bet;
    while(bet>balance) {
        cout << "Your bet is higher than your balance, input a lower number: " << endl;
                cin >> bet;
    }
    if(bet<=balance){
    return bet;
    }
    else{
        cout << "Unknown error found. Restart game." << endl;
        exit(1);
    }
}
void start(int arr[], char suit[], int& score, string user) { //Beginning of game, player is given 2 cards
    score = 0;
    if(user == "Player") {
        cout << "╔═════════════════════════════╗" << endl;
        cout << "║      ★ WELCOME TO ★         ║" << endl;
        cout << "║    ★☆★  BLACK JACK  ★☆★     ║" << endl;
        cout << "╚═════════════════════════════╝" << endl;
        cout << "🎴You are given two cards🎴 : ";
        hit(arr, suit, score); 
        cout << " and ";
        hit(arr, suit, score);
        cout << endl;
        cout << "This makes your grand total " << score << endl << endl;
    }
    if(user == "Dealer") {
        cout << "The dealer reveals his face up 🎴:" << endl;
        hit(arr, suit, score);
        cout << endl << endl;
    }
   
}


bool decide(int array[], char suit[], int& score, int& bet, int balance){ //decide function is all the options the player can do
    char choice;
    bool noResp; //No Response is given or invalid answer will make noResp true which will loop the question of the available options to the player
    do{
        noResp = false;
        cout << "Would you like to: " << "(H) Hit" << " (S) Stand" << " (D) Double Down" << endl;
        cin >> choice;
        if((choice == 'H')||(choice == 'h')) {
            cout << "You are given a card 🎴: ";
            hit(array, suit, score);
            cout << endl;
            cout << "This makes your new total: " << score << endl;
            while(score<=21){
                string hitA; 
                cout << "Would you like to hit again?" << "   (Y) Yes" << "     (N) No" << endl;
                cin>> hitA;
                if((hitA == "Y")||(hitA == "Yes")||(hitA == "y")||(hitA == "yes")) {
                    cout << "You are given a card 🎴: ";
                    hit(array, suit, score);
                    cout << endl;

                    cout << "This makes your new total: " << score << endl;
                } 
                if((hitA == "N")||(hitA == "No")||(hitA == "n")||(hitA == "no")) {
                    return false;
                } 
                if(score>21) {
                    cout << "You lose!" << endl;
                    return false;
                }
            }
        }
        else if((choice == 'S')||(choice == 's')) {
            return false;
        }
        else if((choice == 'D') || (choice == 'd')) {
            // Double down logic
            if(balance>=bet*2) {
                bet *= 2; // Double the bet
                cout << "You doubled down! Your bet is now " << bet << endl;
                cout << "You are given one final card 🎴: ";
                hit(array, suit, score); // Give one more card
                cout << endl;
                cout << "This makes your final total: " << score << endl;

                if(score > 21) {
                    cout << "You lose!" << endl;
                }

                return false; // Stand after doubling down
            }
            else {
                cout << "Not enough balance to double bet, choose a other option. " << endl;
                noResp =true;
            }
        }
        else{
            noResp=true;
            cout << choice << " was not a valid answer. Try again." << endl;
        }
    }
    while(noResp==true);
}
bool playA(){
    char answer;
    while(true) {
        cout << "Would you like to play again?  (Y) Yes   (N) No" << endl;
        cin>>answer;
        if ((answer == 'Y')||(answer == 'y')) {
            return true;
        }
        else if ((answer == 'N')||(answer == 'n')) {
                    return false;
        }
        else{
            cout << "The option " << answer << " was not found, try again." << endl;
        }
    }
}

void deal(int arr[], char suit[], int& score) {
    cout << endl;
    cout << "The dealer reveals his face down 🎴: ";
    hit(arr, suit, score);
    cout << endl;
    cout << "The dealers total is: " << score << endl;
    while(score<17) {
        cout << "The dealer hits again 🎴: ";
        hit(arr, suit, score);
        cout << endl;
    }
}

void winner(int player, int dealr, int bet, int& balance, vector<int>& highestWins) {
    static int wins = 0;
    static int lost = 0;
    static int gamesT = 0;
    if (dealr > 21) {
        cout << "The dealer busted! You win $" << bet << "!" << endl;
        balance += bet;
        wins++;
        highestWins.push_back(balance); // Update highest wins
    } 
    else if (player > 21) {
        cout << "You busted! The dealer wins $" << bet << "!" << endl;
        balance -= bet;
        lost++;
    } 
    else if (player > dealr) {
        cout << "You win $" << bet << "! Your score was " << player << " while the dealer was " << dealr << endl;
        balance += bet;
        wins++;
        highestWins.push_back(balance); // Update highest wins
    } 
    else if (dealr > player) {
        cout << "The dealer wins $" << bet << "! The dealer score was " << dealr << " while your score was " << player << endl; 
        lost++;
        balance -= bet;
    } 
    else if (dealr == player) {
        cout << "It was a tie! Both player and dealer got " << player << endl;
    }
    
    gamesT++;
    
    cout << endl;
    cout << "Your new balance is: " << balance << endl;
    cout << "Games won: " << wins << endl;
    cout << "Games lost: " << lost << endl;
    cout << "Games played: " << gamesT << endl << endl;
}

void fillAr(int arr[], const int SIZE){ //Fills the array with random cards
    for(int i = 0; i<SIZE; i++) {
        arr[i] = rand()%10+1;
    }
}

void fillSu(char arr[], const int SIZE) { //Divides the array into 4 sections (13 suits for each section)
    for(int i = 0; i<SIZE; i++) {
        if(i<13) {
            arr[i] = 'S';
        }
        else if(i<26) {
            arr[i] = 'D';
        }
        else if(i<39) {
            arr[i] = 'H';
        }
        else if(i<52) {
            arr[i] = 'C';
        }
    }
}
void prinAr(int arr[], const int SIZE, int newLin){
    for(int i = 0; i<SIZE; i++) {
        cout << setw(3) << arr[i] << "";
        if((i+1)%newLin==0) {
            cout << endl;
        }
    }
}
string nameC(int num, char suits[], int index) {
    int tenR;
    string name;
    switch(num) {
        case 1: name = "Ace";
                break;
        case 2: name = "Two";
                break;
        case 3: name = "Three";
                break;
        case 4: name = "Four";
                break;
        case 5: name = "Five";
                break;
        case 6: name = "Six";
                break;
        case 7: name = "Seven";
                break;
        case 8: name = "Eight";
                break;
        case 9: name = "Nine";
                break;
        case 10: name = "Ten";
                break;
        case 11: name = "Ace";
                break; 
    }
    if(name == "Ten") {
        tenR = rand()%3+1;
        if(tenR == 1)  {
            name = "Ten";
         }
        else if(tenR == 2) {
            name = "Jack";
        }
        else if(tenR == 3) {
            name = "Queen";
        }
        else {
            name = "King";
        }
    }
    if(suits[index] == 'S') {
        name += " of Spades";
    }
    if(suits[index] == 'D') {
        name += " of Diamonds";
    }
    if(suits[index] == 'H') {
        name += " of Hearts";
    }
    if(suits[index] == 'C') {
        name += " of Clubs";
    }
    return name;
}
string suitC(char suits[], int index) {
    if(suits[index] == 'S') {
        return "Spades";
    }
    if(suits[index] == 'D') {
        return "Diamonds";
    }
    if(suits[index] == 'H') {
        return "Hearts";
    }
    if(suits[index] == 'C') {
        return "Clubs";
    }
}
void hit(int array[], char suit[], int &total) {
    string nameS;
    int numR;
    int pullC;
    
    numR = rand()%51+0; //Gets a random number to utilize on both arrays
    nameS = suitC(suit, numR); //Parallel Array, connects integer array index to char array index to get suit
   
    pullC = array[numR];
    if((total<=10)&&(pullC==1)) { //Decides if 11 or 1 is the best choice if the player/dealer pulls an Ace
        pullC = 11;
    }
    total += pullC; //Adds to players/dealers total
    
    cout << nameC(pullC, suit, numR);
    
}


void saveGameState(const int balance, const int wins, const int losses) {
    ofstream outFile("gameState.txt");
    if (outFile.is_open()) {
        outFile << balance << endl;
        outFile << wins << endl;
        outFile << losses << endl;
        outFile.close();
    } else {
        cout << "Unable to open file for saving game state." << endl;
    }
}

void loadGameState(int &balance, int &wins, int &losses) {
    ifstream inFile("gameState.txt");
    if (inFile.is_open()) {
        inFile >> balance;
        inFile >> wins;
        inFile >> losses;
        inFile.close();
    } else {
        cout << "Unable to open file for loading game state. Starting new game." << endl;
        balance = 1000;
        wins = 0;
        losses = 0;
    }
}


void saveHighestWins(const vector<int>& highestWins) {
    ofstream outFile("highestWins.txt");
    if (outFile.is_open()) {
        for (int win : highestWins) {
            outFile << win << endl;
        }
        outFile.close();
    } else {
        cout << "Unable to open file for saving highest wins." << endl;
    }
}

void loadHighestWins(vector<int>& highestWins) {
    ifstream inFile("highestWins.txt");
    if (inFile.is_open()) {
        int win;
        while (inFile >> win) {
            highestWins.push_back(win);
        }
        inFile.close();
    } else {
        cout << "Unable to open file for loading highest wins." << endl;
    }
}

void bubbleSort(vector<int>& vec) {
    int n = vec.size();
    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-i-1; j++) {
            if (vec[j] > vec[j+1]) {
                swap(vec[j], vec[j+1]);
            }
        }
    }
}